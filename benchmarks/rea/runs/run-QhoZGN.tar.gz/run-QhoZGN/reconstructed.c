#include <ctype.h>
#include <string.h>
typedef unsigned int uint;
typedef unsigned char byte;

int catalog_rank(char *query)

{
  int iVar1;
  size_t sVar2;
  char *query_local;
  
  sVar2 = strlen(query);
  if (sVar2 < 3) {
    iVar1 = -1;
  }
  else {
    iVar1 = tolower((uint)(byte)*query);
    if (iVar1 == 0x67) {
      iVar1 = 7;
    }
    else {
      iVar1 = strcmp(query,"native");
      if (iVar1 == 0) {
        iVar1 = 0xb;
      }
      else {
        iVar1 = 0;
      }
    }
  }
  return iVar1;
}

