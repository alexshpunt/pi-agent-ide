import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { cp, mkdir, mkdtemp, readFile, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import path from "node:path";
import { performance } from "node:perf_hooks";
import { fileURLToPath, pathToFileURL } from "node:url";
import { isDeepStrictEqual, promisify } from "node:util";
import { validateApplication } from "./validate-js.mjs";
import { validateNative } from "./validate-native.mjs";

const execute = promisify(execFile);
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");

/** Measure one private REA connection without a Pi extension or any model calls. */
export async function runMcpBaseline({ reaRoot, cliRun, resultsRoot, ideRoot }) {
  reaRoot = path.resolve(reaRoot);
  cliRun = path.resolve(cliRun);
  ideRoot = path.resolve(ideRoot);
  await execute("git", ["-C", ideRoot, "fetch", "origin", "develop"]);
  const revision = async (ref) =>
    (await execute("git", ["-C", ideRoot, "rev-parse", ref])).stdout.trim();
  const commit = await revision("HEAD");
  assert.equal(commit, await revision("origin/develop"));
  const idePackage = JSON.parse(await readFile(path.join(ideRoot, "package.json"), "utf8"));
  const cliReport = JSON.parse(await readFile(path.join(cliRun, "result.json"), "utf8"));
  const reaPackage = JSON.parse(await readFile(path.join(reaRoot, "package.json"), "utf8"));
  const requireRea = createRequire(path.join(reaRoot, "package.json"));
  const { Client } = await import(
    pathToFileURL(requireRea.resolve("@modelcontextprotocol/client")).href
  );
  const { StdioClientTransport } = await import(
    pathToFileURL(requireRea.resolve("@modelcontextprotocol/client/stdio")).href
  );
  await mkdir(resultsRoot, { recursive: true });
  const root = await mkdtemp(path.join(path.resolve(resultsRoot), "mcp-"));
  const home = path.join(root, "home");
  const tmp = path.join(root, "tmp");
  await Promise.all([mkdir(home), mkdir(tmp)]);
  const native = path.join(root, "catalog");
  const app = path.join(root, "electron");
  await Promise.all([
    cp(path.join(cliRun, "catalog"), native),
    cp(path.join(cliRun, "electron"), app, { recursive: true }),
  ]);
  assert.equal(digest(await readFile(native)), cliReport.nativeSha256);
  const entry = path.join(reaRoot, "scripts", "rea.mjs");
  assert.equal(digest(await readFile(entry)), cliReport.rea.entrySha256);
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [entry, "--mcp"],
    cwd: root,
    env: {
      PATH: process.env.PATH,
      HOME: home,
      XDG_CONFIG_HOME: home,
      XDG_CACHE_HOME: home,
      TMPDIR: tmp,
      JAVA_HOME: process.env.JAVA_HOME,
      GHIDRA_INSTALL_DIR: process.env.GHIDRA_INSTALL_DIR,
    },
    stderr: "pipe",
  });
  const client = new Client({ name: "lpt-709-no-model-baseline", version: "1" });
  let stderr = "";
  transport.stderr.on("data", (chunk) => {
    stderr += chunk.toString();
  });
  const records = [];
  const report = {
    kind: "deterministic-mcp-baseline",
    startedAt: new Date().toISOString(),
    root,
    cliRun,
    ide: { source: ideRoot, version: idePackage.version, commit, piChildLaunched: false },
    rea: { version: reaPackage.version, entrySha256: digest(await readFile(entry)) },
    nativeTools: cliReport.nativeTools,
    runnerSha256: digest(await readFile(fileURLToPath(import.meta.url))),
    modelCalls: 0,
    records,
  };
  const save = async () => {
    await Promise.all([
      writeFile(path.join(root, "result.json"), JSON.stringify(report, null, 2) + "\n"),
      writeFile(path.join(root, "server.stderr"), stderr),
    ]);
  };
  const call = async (id, name, args = {}, expectedError = false) => {
    const request = { name, arguments: args };
    const record = { id, request, expectedError };
    records.push(record);
    await writeFile(path.join(root, `${id}.request.json`), JSON.stringify(request, null, 2));
    const started = performance.now();
    try {
      const response = await client.callTool(request, { timeout: 360000, maxTotalTimeout: 360000 });
      const serialized = JSON.stringify(response, null, 2);
      await writeFile(path.join(root, `${id}.response.json`), serialized);
      record.elapsedMs = Math.round(performance.now() - started);
      record.responseBytes = Buffer.byteLength(serialized);
      record.isError = response.isError === true;
      await save();
      assert.equal(record.isError, expectedError, `${id} unexpected tool status`);
      return response.structuredContent;
    } catch (failure) {
      record.elapsedMs = Math.round(performance.now() - started);
      record.exception = { name: failure.name, message: failure.message, code: failure.code };
      await save();
      throw failure;
    }
  };
  try {
    const started = performance.now();
    await client.connect(transport);
    report.connectMs = Math.round(performance.now() - started);
    report.serverPid = transport.pid;
    const catalog = await client.listTools();
    await writeFile(path.join(root, "tools.json"), JSON.stringify(catalog, null, 2));
    report.toolCount = catalog.tools.length;
    await call("session-empty", "binary_session");
    const application = await call("application", "analyze_javascript_application", {
      input_path: app,
    });
    report.applicationValidation = validateApplication(application);
    assert.equal(report.applicationValidation.passed, true);
    const source = { kind: "retained-evidence", evidence_id: application.evidence_id };
    const selected = await call("retained-summary", "inspect_analysis_view", {
      source,
      view: { kind: "summary" },
    });
    report.retainedParentMatches =
      selected.normalized_result.parent_evidence_id === application.evidence_id;
    await call("open-native", "open_binary", { path: native, provider_id: "ghidra" });
    await call("session-native", "binary_session");
    const dossier = await call("function-cold", "analyze_function", { procedure: "catalog_rank" });
    report.nativeValidation = validateNative(dossier, cliReport.nativeSha256);
    assert.equal(report.nativeValidation.passed, true);
    const repeated = await call("function-repeated", "analyze_function", {
      procedure: "catalog_rank",
    });
    report.repeatedEvidenceMatches = isDeepStrictEqual(dossier, repeated);
    await call("search-new-query", "search_procedures", { pattern: "catalog" });
    await call("retained-after-open", "inspect_analysis_view", {
      source,
      view: { kind: "summary" },
    });
    await call("close-native", "close_binary");
    const missing = await call(
      "retained-after-close",
      "inspect_analysis_view",
      { source, view: { kind: "summary" } },
      true,
    );
    report.missingAfterClose = missing;
    await call("session-closed", "binary_session");
    report.finishedAt = new Date().toISOString();
  } catch (failure) {
    report.failure = { name: failure.name, message: failure.message };
    throw failure;
  } finally {
    const started = performance.now();
    try {
      await client.close();
      await transport.close();
      report.closeMs = Math.round(performance.now() - started);
      try {
        process.kill(report.serverPid, 0);
        report.serverStillAlive = true;
      } catch (failure) {
        if (failure.code !== "ESRCH") throw failure;
        report.serverStillAlive = false;
      }
    } catch (failure) {
      report.cleanupError = { name: failure.name, message: failure.message };
    }
    await save();
  }
  return report;
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  const [reaRoot, cliRun, resultsRoot, ideRoot] = process.argv.slice(2);
  if (!reaRoot || !cliRun || !resultsRoot || !ideRoot) {
    throw new Error(
      "Usage: node mcp-baseline.mjs REA_PACKAGE_ROOT CLI_RUN RESULTS_ROOT CURRENT_IDE_ROOT",
    );
  }
  const report = await runMcpBaseline({ reaRoot, cliRun, resultsRoot, ideRoot });
  console.log(JSON.stringify(report, null, 2));
}
